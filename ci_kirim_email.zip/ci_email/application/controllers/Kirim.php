<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Kirim extends CI_Controller {
 
    /**
     * Author :  Wildan Fuady
     * Web Pribadi :  https://www.wildanfuady.com
     * Web Tutorial :  https://www.saungnulis.tk
     */
    public function index()
    {
        // Konfigurasi email
        $config = [
               'useragent' => 'CodeIgniter',
               'protocol'  => 'smtp',
               'mailpath'  => '/usr/sbin/sendmail',
               'smtp_host' => 'ssl://smtp.gmail.com',
               'smtp_user' => 'email_anda@gmail.com', // Ganti dengan email gmail Anda
               'smtp_pass' => 'password_anda', // Password gmail Anda
               'smtp_port' => 465,
               'smtp_keepalive' => TRUE,
               'smtp_crypto' => 'SSL',
               'wordwrap'  => TRUE,
               'wrapchars' => 80,
               'mailtype'  => 'html',
               'charset'   => 'utf-8',
               'validate'  => TRUE,
               'crlf'      => "\r\n",
               'newline'   => "\r\n",
           ];
 
        // Load library email dan konfigurasinya
        $this->load->library('email', $config);
 
        // Email dan nama pengirim
        $this->email->from('no-reply@masrud.com', 'Wildan Fuady');
 
        // Email penerima
        $this->email->to('wildanfuady@gmail.com'); // Ganti dengan email tujuan Anda
 
        // Lampiran email, isi dengan url/path file
        $this->email->attach('');
 
        // Subject email
        $this->email->subject('Kirim Email dari Wildan Fuady');
 
        // Isi email
        $this->email->message("Ini adalah contoh email CodeIgniter yang dikirim menggunakan SMTP email Google (Gmail).<br><br> Klik <strong><a href='http://www.saungnulis.tk/2018/12/tutorial-kirim-email-via-smpt-gmail-dengan-codeigniter.html' target='_blank' rel='noopener'>disini</a></strong> untuk melihat tutorialnya.");
 
        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            echo 'Sukses! email berhasil dikirim.';
        } else {
            echo 'Error! email tidak dapat dikirim.';
        }
    }
}
?>